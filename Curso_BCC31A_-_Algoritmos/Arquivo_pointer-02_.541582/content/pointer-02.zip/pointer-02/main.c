#include <stdio.h>
#include <stdlib.h>

int* concat(int* v1, int n1, int* v2, int n2, int* n3) {
    *n3 = n1 + n2;
    int* v3 = malloc(*n3 * sizeof(int));
    int i;
    for (i = 0; i < n1; i++) {
        v3[i] = v1[i];
    }
    for (; i < *n3; i++) {
        v3[i] = v2[i-n1];
    }
    return v3;
}
//               int v[]
void printVector(int *v, int n) {
    printf("[ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("]\n");
}

int** mallocMatrix(int lin, int col) {
    // alocando o array de ponteiros de inteiros
    // (array que tera os enderecos dos arrays)
    int** m = malloc(lin * sizeof(int*));

    for (int i = 0; i < lin; i++) {
        m[i] = malloc(col * sizeof(int));
    }
    return m;
}

void printMatrix(int** m, int rows, int cols) {
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            printf("%2d ", m[r][c]);
        }
        printf("\n");
    }
}

void initValues(int** m, int rows, int cols, int start) {
    int count = start;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            m[r][c] = count;
            count++;
        }
    }
}

int main()
{
    int v1[] = {1,2,3,4,5,6};
    int v2[] = {4,5,6};
    int n3;
    int* v3 = concat(v1, 6, v2, 3, &n3);
    free(v3);
    printVector(v3, n3);
    // faz algo com v3...


    // criando a matriz
    int** m = mallocMatrix(3, 5);

    // iniciar a matriz
    initValues(m, 3, 5, 1);

    // imprime a matriz
    printMatrix(m, 3, 5);

    return 0;
}
