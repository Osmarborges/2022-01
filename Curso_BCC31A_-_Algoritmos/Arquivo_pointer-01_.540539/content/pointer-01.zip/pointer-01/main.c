#include <stdio.h>
#include <stdlib.h>

void swapVars(int* px, int* py) {
    int temp = *px;
    *px = *py;
    *py = temp;
}

//void printVetor(int v[], int n) {
void printVetor(int* v, int n) {
    printf("[ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("]\n");
}

int* createAndInitVetor(int n) {
    // Aloca manualmente/dinamicamente o array
    // de n posicoes de inteiros.
    // Deve ser liberado com free() ou quando
    // o programa terminar.
    int* v = malloc(n * sizeof(int));

    for (int i = 0; i < n; i++) {
        v[i] = (i+1)*2;
    }
    return v;
}

int main()
{
    // guardando endereco de variaveis automaticas
    int a = 10;
    int* pa = &a;

    printf("size  *pa:%d  a:%d\n", sizeof(pa), sizeof(a));
    printf("a:  %p - %d\n", &a, a);
    printf("pa: %p - %d\n", pa, *pa);

    *pa = 15;
    printf("a:  %p - %d\n", &a, a);
    printf("pa: %p - %d\n", pa, *pa);

    // usando ponteiros para referenciar variaveis
    // de fora do escopo da funcao
    int x = 10;
    int y = 20;
    swapVars(&x, &y);
    printf("x: %d  y: %d\n", x, y);

    // array alocado manualmente
    int* v = createAndInitVetor(10);
    printVetor(v, 10);

    return 0;
}
