#include <stdio.h>
#include "screen.h"

void test() {
    setColor(COLOR_FG_BLUE);
    printf("\nUSANDO CORES NO TERMINAL\n");

    setColor(COLOR_FG_RED);
    printf("OBS:");
    setColor(COLOR_FG_WHITE);
    printf(" nem todos os terminais oferecem suporte\n\n");

    int size = 10;

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < 2*size; j++) {
            randomBGColor();
            printf(" ");
        }
        resetColor();
        printf("\n");
    }
    resetColor();
    printf("\n\n");
}

void clearBuffer() {
    // faz a leitura de vários caracteres (*) e encerra no \n ([^\n])
    scanf("%*[^\n]"); 
    // lê o próximo caractere: neste caso, o ‘\n’
    scanf("%*c"); 
}

void main() {
    char nome[15]; // 14 + '\0'
    char email[10]; // 9 + '\0'

    setColor(COLOR_BG_MAGENTA);
    clearScreen();
    resetColor();

    setColor(COLOR_FG_BLUE);
    printf("TESTES DE LEITURA COM SCANF\n\n");

    resetColor();
    setColor(COLOR_FG_CYAN);
    printf("Nome: ");

    setColor(COLOR_FG_BLACK);
    setColor(COLOR_BG_GREEN);
    scanf(" %14[^\n]", nome);
    clearBuffer();

    setCursor(2,0);

    resetColor();
    setColor(COLOR_FG_CYAN);
    printf("emal: ");

    setColor(COLOR_FG_BLACK);
    setColor(COLOR_BG_GREEN);    
    scanf(" %9[^\n]", email);
    clearBuffer();

    resetColor();
    printf("Campos %s, %s\n", nome, email);
}

