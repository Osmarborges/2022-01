#include <stdio.h>
#include <stdlib.h>
#include "screen.h"

int cursorRow = 0;
int cursorCol = 0;

void setCursor(int row, int col) {
  cursorRow = row+1;
  cursorCol = col+1;
  printf("\033[%d;%dH", row, col);
}

int getCursorRow() {
    return cursorRow;
}

int getCursorCol() {
    return cursorCol;
}

void resetColor() {
    setColor(COLOR_RESET);
}

void setColor(int color) {
  printf("\033[%dm", color);
}

void clearScreen() {
  printf("\033[2J");
}

void randomBGColor() {
    randomColor(COLOR_BG_BLACK, 8);
}

void randomFGColor() {
    randomColor(COLOR_FG_BLACK, 8);
}

void randomColor(int start, int range) {
    int color = start + rand() % range;
    setColor(color);
}
