#ifndef SCREEN_H_INCLUDED
#define SCREEN_H_INCLUDED

// ref: http://ascii-table.com/ansi-escape-sequences.php

#define COLOR_FG_BLACK   30
#define COLOR_FG_RED     31
#define COLOR_FG_GREEN   32
#define COLOR_FG_YELLOW  33
#define COLOR_FG_BLUE    34
#define COLOR_FG_MAGENTA 35
#define COLOR_FG_CYAN    36
#define COLOR_FG_WHITE   37

#define COLOR_BG_BLACK   40
#define COLOR_BG_RED     41
#define COLOR_BG_GREEN   42
#define COLOR_BG_YELLOW  43
#define COLOR_BG_BLUE    44
#define COLOR_BG_MAGENTA 45
#define COLOR_BG_CYAN    46
#define COLOR_BG_WHITE   47

#define COLOR_RESET 0

extern int cursorRow;
extern int cursorCol;

void setCursor(int row, int col);
int getCursorRow();
int getCursorCol();
void resetColor();
void setColor(int color);
void clearScreen();
void randomBGColor();
void randomFGColor();
void randomColor(int start, int range);

#endif // SCREEN_H_INCLUDED
