#include <stdio.h>
#include <stdlib.h>

// outra forma de passar a referenia de um array para uma funcao
// void printArray(int* v, int n) {
void printArray(int v[], int n) {
    printf("array: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("\n");
}

void initArray(int v[], int n, int value) {
    for (int i = 0; i < n; i++) {
        v[i] = value;
    }
}

void randArray(int v[], int n) {
    for (int i = 0; i < n; i++) {
        v[i] = (rand() % 10) + 1;
    }
}

// PASSAGEM DE PARAMETRO POR COPIA VS REFERENCIA

// passagem de parametro por copia
void resetInt(int a) {
    a = 0;
}
// passagem de parametro por referencia
void resetVet(int v[]) {
    v[0] = 0;
}

int main()
{
/*
    // diferenca entre passagem de paremtros por copia vs
    // referencia em funcoes
    int num = 99;
    int v[5] = {99, 99, 99, 99, 99};
    resetInt(num);
    resetVet(v);
    printf("num:%d\n v[0]%d\n", num, v[0]);
*/

    int v2[5];
    int v3[]  = {10,20,30,40,50};

    int n4 = 10;
    int v4[n4];

    printArray(v2, 5);
    printArray(v3, 5);

    printArray(v4, n4);
    randArray(v4, n4);
    printArray(v4, n4);

    return 0;
}
