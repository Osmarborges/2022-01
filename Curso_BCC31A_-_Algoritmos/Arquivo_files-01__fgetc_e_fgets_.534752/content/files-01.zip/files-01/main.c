#include <stdio.h>
#include <stdlib.h>

void readFileC() {
    FILE* file;
    file = fopen("main.c","rt"); // read-text
    if (file == NULL) {
        printf("ERRO: Arquivo nao existe.\n");
        return 1;
    }
    /*
    char ch = fgetc(file);
    while ( ch != EOF) {
        printf("%c", ch);
        ch = fgetc(file);
    }
    */
    char ch;
    while ( (ch = fgetc(file)) != EOF ) {
        printf("%c", ch);
    }
    fclose(file);
}

void readFileS() {
    FILE* file;
    file = fopen("main.c","rt"); // read-text
    if (file == NULL) {
        printf("ERRO: Arquivo nao existe.\n");
        return 1;
    }

    int n = 200;
    char buffer[n];
    while (fgets(buffer, n, file) != NULL) {
        printf("[%02d] %s", strlen(buffer), buffer);
    }

    fclose(file);
}


int main()
{
    readFileS();
    return 0;
}
