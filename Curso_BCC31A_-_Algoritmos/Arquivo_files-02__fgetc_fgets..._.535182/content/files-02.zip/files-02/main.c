#include <stdio.h>
#include <stdlib.h>

void readFileChar() {
    FILE* file;
    file = fopen("main.c","rt"); // read-text
    if (file == NULL) {
        printf("ERRO: Arquivo nao existe.\n");
        return 1;
    }
    /*
    char ch = fgetc(file);
    while ( ch != EOF) {
        printf("%c", ch);
        ch = fgetc(file);
    }
    */
    char ch;
    while ( (ch = fgetc(file)) != EOF ) {
        printf("%c", ch);
    }
    fclose(file);
}

void readFileLine() {
    FILE* file;
    file = fopen("main.c","rt"); // read-text
    if (file == NULL) {
        printf("ERRO: Arquivo nao existe.\n");
        return 1;
    }

    int n = 200;
    char buffer[n];
    while (fgets(buffer, n, file) != NULL) {
        printf("[%02d] %s", strlen(buffer), buffer);
    }

    fclose(file);
}

void writeReadFile() {
    FILE* file = fopen("dados.txt","w+"); // write-read
    if (file == NULL) {
        printf("ERRO: Arquivo nao existe.\n");
        return 1;
    }
    // ESCREVE COM FORMATO ESPECIFICO
    // OBSERVACOES:
    // > deve comećar a string de formato com um caractere (coloquei um espaco)
    // > a string %s nao pode conter espacos
    for (int i = 0; i < 10; i++) {
        fprintf(file, " %d - %s - %f", i+1, "texto-de-teste", (i+1)/2.0f);
    }

    // retorna cursor para inicio do arquivo
    rewind(file); // mesmo que fseek(file, 0, SEEK_SET);

    // LE COM FORMATO ESPECIFICO
    // Deve ser o mesmo formato usado para escrita
    int a;
    float b;
    char str[20];
    while (fscanf(file, " %d - %s - %f", &a, str, &b) != EOF) {
        printf("dado: %d, %s, %f\n", a, str, b);
    }
    fclose(file);
}


int main()
{
    //readFileChar();
    //readFileLine();
    writeReadFile();
    return 0;
}
